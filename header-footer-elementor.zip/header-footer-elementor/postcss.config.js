module.exports = {
	plugins: {
		tailwindcss: {}, // Enables Tailwind CSS
		autoprefixer: {}, // Enables Autoprefixer for cross-browser support
	},
};
